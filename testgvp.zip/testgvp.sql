-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `jenis_produk`;
CREATE TABLE `jenis_produk` (
  `id_jenis_produk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jenis_produk` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jenis_produk`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `jenis_produk` (`id_jenis_produk`, `nama_jenis_produk`) VALUES
(1,	'Kipas Angin'),
(2,	'Magic Com'),
(3,	'Kompor Gas');

DROP TABLE IF EXISTS `produk`;
CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL AUTO_INCREMENT,
  `nama_produk` varchar(50) NOT NULL,
  `harga` double NOT NULL,
  `id_jenis_produk` int(11) NOT NULL,
  `berat` int(11) DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_produk`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga`, `id_jenis_produk`, `berat`, `satuan`) VALUES
(1,	'Kipas Angin Cosmos 12 in',	200000,	1,	5,	'Kg'),
(2,	'Kipas Angin Miyako 12 Inchi',	170000,	1,	5,	'Kg'),
(3,	'Magic Com Miyako AD102',	300000,	2,	10,	'Kg'),
(4,	'Magis Com Rinnai',	350000,	2,	10,	'Kg');

-- 2021-07-28 04:37:34
