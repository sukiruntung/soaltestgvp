<?php

// konfigurasi koneksi

define("HOST", "localhost"); // Host database
define("USER", "root"); // Usernama database
define("PASSWORD", "ois"); // Password database
define("DATABASE", "testgvp");

// script koneksi php postgree
$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

if($mysqli->connect_error){
	trigger_error('Koneksi ke database gagal: ' . $mysqli->connect_error, E_USER_ERROR);	
} 
?>